# comentariu

print("Hello, World!")

# acest cod este un exemplu simplu de program Python care afișează mesajul "Hello, World!" pe ecran.

# modul standard
import sys

# modul extern instalat
import pandas

import random

x = random.randint(10, 100)
print(x)

a = [1, 2, 3]
for i in a:
    print(i)
    
